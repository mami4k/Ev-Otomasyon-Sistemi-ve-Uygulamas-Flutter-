import RPi.GPIO as GPIO
import time
import paho.mqtt.client as mqtt

# GPIO pin numaralarını tanımla
TRIG = 23  # Mesafe sensörü TRIG pini
ECHO = 24  # Mesafe sensörü ECHO pini
SERVO = 4 # Servo motor pin

# MQTT broker ayarları
broker_address = "broker.emqx.io"
port = 1883
topic1 = "control_center"
topic2 = "door"
client_id = "mami"

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id)
client.connect(broker_address, port=port)


# GPIO modunu belirleme
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

# Mesafe sensörü pinlerini tanımla
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

# Servo motor pinini tanımla
GPIO.setup(SERVO, GPIO.OUT)
servo_pwm = GPIO.PWM(SERVO, 50) # PWM frekansını 50 Hz olarak ayarla

# Servo motorun başlangıç konumunu ayarla
servo_pwm.start(0)

def mesafe_olc():
    # Mesafe sensöründen mesafeyi ölç
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)
    
    pulse_start = time.time()
    pulse_end = time.time()
    
    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()
    
    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()
    
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)
    
    return distance

try:
    while True:
        # Mesafe ölçümü yap
        mesafe = mesafe_olc()
        print("Ölçülen Mesafe:", mesafe, "cm")        
        # MQTT üzerinden mesafe verisini yayınla
        client.publish(topic1, mesafe)
        
        
        # Belirlenen eşik değeri (örneğin 20 cm) aştığında servo motoru hareket ettir
        if mesafe < 20:
            durum = 1;
            # Servo motoru 90 dereceye döndür
            servo_pwm.ChangeDutyCycle(12.5) # 90 derece
            client.publish(topic2, durum)
            time.sleep(4)
            
        else:
            durum = 0;
            # Servo motoru 0 dereceye döndür (kapalı konum)
            servo_pwm.ChangeDutyCycle(2.5) # 0 derece
            client.publish(topic2, durum)
            time.sleep(4)
            
except KeyboardInterrupt:
    # Program kapatılınca GPIO pinlerini temizle
    servo_pwm.stop()
    GPIO.cleanup()  
