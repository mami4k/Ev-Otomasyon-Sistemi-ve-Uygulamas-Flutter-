import RPi.GPIO as GPIO
import time

# Ses sensörünün bağlı olduğu pin
ses_sensoru_pin = 23

# Röle modülünün bağlı olduğu pin
rele_pin = 4

# GPIO ayarları
GPIO.setmode(GPIO.BCM)
GPIO.setup(ses_sensoru_pin, GPIO.IN)
GPIO.setup(rele_pin, GPIO.OUT)

try:
    while True:
        # Ses sensöründen gelen sinyali oku
        ses_durumu = GPIO.input(ses_sensoru_pin)
        
        if ses_durumu:
            print("Ses algılandı! Röle açılıyor...")
            GPIO.output(rele_pin, GPIO.HIGH)  # Röleyi aktifleştir
            time.sleep(5)  # Röle 5 saniye boyunca aktif kalacak
            GPIO.output(rele_pin, GPIO.LOW)  # Röleyi kapat
        else:
            print("Ses algılanmadı.")
        
        # Küçük bir gecikme ekle
        time.sleep(0.1)

except KeyboardInterrupt:
    GPIO.cleanup()
