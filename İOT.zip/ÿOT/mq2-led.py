import RPi.GPIO as GPIO
import time

# MQ2 sensörünün bağlı olduğu pin
mq2_pin = 23

# LED'in bağlı olduğu pin
led_pin = 4

# GPIO ayarları
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(mq2_pin, GPIO.IN)
GPIO.setup(led_pin, GPIO.OUT)

try:
    while True:
        # MQ2 sensöründen gelen sinyali oku
        gaz_durumu = GPIO.input(mq2_pin)
        
        if gaz_durumu:
            print("Gaz algılandı! LED yanacak.")
            GPIO.output(led_pin, GPIO.HIGH)  # LED'i yak
        else:
            print("Gaz algılanmadı. LED sönecek.")
            GPIO.output(led_pin, GPIO.LOW)  # LED'i söndür
        
        # Küçük bir gecikme ekle
        time.sleep(1)

except KeyboardInterrupt:
    GPIO.cleanup()
