import RPi.GPIO as GPIO
import time
import datetime
import paho.mqtt.client as mqtt

# MQTT Ayarları
broker_address = "broker.emqx.io"
port = 1883
topic = "isik"
client_id = "mami"

# GPIO Ayarları
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

# MQTT İstemci Ayarları
client = mqtt.Client(client_id)
client.connect(broker_address, port=port)

motion_sensor_pin = 4
led_pin = 17  # LED'in bağlı olduğu GPIO pini
GPIO.setup(motion_sensor_pin, GPIO.IN)
GPIO.setup(led_pin, GPIO.OUT)


try:
    while True:
        motion_detected = GPIO.input(motion_sensor_pin)
        if motion_detected:
            now = str(datetime.datetime.now())
            print(f"Motion detected at: {now}")
            
            # LED'i yak
            GPIO.output(led_pin, GPIO.HIGH)
            
            # MQTT Mesajı Gönderme
            payload = "Motion Detected"
            client.publish(topic, payload)
        else:
            # Hareket algılanmadığında LED'i kapat
            GPIO.output(led_pin, GPIO.LOW)
        
        time.sleep(3)

except KeyboardInterrupt:
    print("Cleanup")
    GPIO.cleanup()