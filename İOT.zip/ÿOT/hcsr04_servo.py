import RPi.GPIO as GPIO
import time

# GPIO pin numaralarını tanımla
TRIG = 23  # Mesafe sensörü TRIG pini
ECHO = 24  # Mesafe sensörü ECHO pini
SERVO = 4 # Servo motor pin

# GPIO modunu belirleme
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

# Mesafe sensörü pinlerini tanımla
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

# Servo motor pinini tanımla
GPIO.setup(SERVO, GPIO.OUT)
servo_pwm = GPIO.PWM(SERVO, 50) # PWM frekansını 50 Hz olarak ayarla

# Servo motorun başlangıç konumunu ayarla
servo_pwm.start(0)

def mesafe_olc():
    # Mesafe sensöründen mesafeyi ölç
    GPIO.output(TRIG, True)
    time.sleep(0.5)
    GPIO.output(TRIG, False)
    
    pulse_start = time.time()
    pulse_end = time.time()
    
    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()
    
    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()
    
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)
    
    return distance

try:
    while True:
        # Mesafe ölçümü yap
        mesafe = mesafe_olc()
        print("Ölçülen Mesafe:", mesafe, "cm")
        
        # Belirlenen eşik değeri (örneğin 20 cm) aştığında servo motoru hareket ettir
        if mesafe < 20:
            # Servo motoru 90 dereceye döndür
            servo_pwm.ChangeDutyCycle(12.5) # 90 derece
            time.sleep(1)
        else:
            # Servo motoru 0 dereceye döndür (kapalı konum)
            servo_pwm.ChangeDutyCycle(2.5) # 0 derece
            time.sleep(1)

except KeyboardInterrupt:
    # Program kapatılınca GPIO pinlerini temizle
    servo_pwm.stop()
    GPIO.cleanup()                                  
