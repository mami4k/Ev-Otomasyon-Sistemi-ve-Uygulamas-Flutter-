import pandas as pd

# Sonuçları tablo olarak düzenleme
data = {
    "Sonuçlar": [
        "Gerçek Zamanlı Kontrol ve İzleme",
        "Çoklu Platform Desteği",
        "Güvenlik ve Konfor",
        "Verimli Donanım Kullanımı"
    ],
    "Açıklama": [
        "Sensörler aracılığıyla elde edilen veriler anlık olarak işlenmiş ve kullanıcıların mobil cihazları üzerinden izlenebilmiştir.",
        "Hem Android hem de iOS platformlarında çalışan uygulamalar sayesinde, kullanıcılar evlerinin durumunu farklı cihazlardan takip edebilmiştir.",
        "Hareket algılayıcı ve diğer sensörler sayesinde evdeki güvenlik ve konfor düzeyi artırılmıştır. Örneğin, hareket algılandığında lambaların otomatik olarak açılması veya sıcaklık/nem sensörleriyle ortam koşullarının optimize edilmesi sağlanmıştır.",
        "Raspberry Pi 4'ün sağladığı donanım özellikleri, sensör verilerinin hızlı ve verimli bir şekilde işlenmesine olanak tanımıştır."
    ]
}

# DataFrame oluşturma
df = pd.DataFrame(data)

# DataFrame'i Excel dosyasına kaydetme
excel_path = '/mnt/data/sonuclar.xlsx'
df.to_excel(excel_path, index=False)

excel_path
