import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

# PIR sensörünün bağlı olduğu GPIO pinini belirtin
PIR_PIN = 23
# Röle bağlı olduğu GPIO pinini belirtin
RELAY_PIN = 4

def setup():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(PIR_PIN, GPIO.IN)
    GPIO.setup(RELAY_PIN, GPIO.OUT)
    print("Sistem hazır. Hareket algılanıyor...")

def pir_motion():
    return GPIO.input(PIR_PIN)

def control_relay(state):
    GPIO.output(RELAY_PIN, state)

def main():
    try:
        setup()
        while True:
            if pir_motion():
                print("Hareket algılandı! Fan çalışıyor...")
                control_relay(GPIO.HIGH)  # Röleyi aktif et (fanı çalıştır)
                time.sleep(5)  # 30 saniye boyunca fanı çalıştır
            else:
                control_relay(GPIO.LOW)  # Röleyi devre dışı bırak (fanı durdur)
                print("Fan durduruldu.")
            time.sleep(1)  # Hareket algılama döngüsünü 0.1 saniyede bir kontrol et
    except KeyboardInterrupt:
        GPIO.cleanup()

if __name__ == "__main__":
    main()
