import RPi.GPIO as GPIO
import time
import paho.mqtt.client as mqtt
import datetime

ir_pin = 17
buzzer_pin = 27

broker_address = "broker.emqx.io"
port = 1883
topic = "alarm"
client_id = "mami"

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id)
client.connect(broker_address, port=port)

# GPIO ayarları
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(ir_pin, GPIO.IN)  # IR sensörünün başlangıç durumu HIGH
GPIO.setup(buzzer_pin, GPIO.OUT)  # Buzzer pinini çıkış olarak ayarla

try:
    while True:
        # IR sensöründen gelen sinyali oku
        ir_state = GPIO.input(ir_pin)

        if ir_state:
            print("Ateş algılandı! LED yanacak.")
            GPIO.output(buzzer_pin, GPIO.HIGH)  # Buzzer'i aktifleştir
            message = "Ateş algılandı"

        else:  
            print("Ateş algılanmadı. LED sönecek.")
            GPIO.output(buzzer_pin, GPIO.LOW)  # Buzzer'i devre dışı bırak
            message = "Ateş algılanmadı"
            
        # MQTT mesajını gönder
        client.publish(topic, message)
        
        # Küçük bir gecikme ekle
        time.sleep(3)

except KeyboardInterrupt:
    GPIO.cleanup()
